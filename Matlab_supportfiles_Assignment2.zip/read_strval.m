function val = read_strval(str)
%val = read_strval(str)
%Reads the numeric value val of the string str
%Returns zero if str is blank
%Written by Jeff Freymueller, Stanford University 2/8/95

if isempty(sscanf(str,'%f',1))
   val = 0;
else
   val = sscanf(str,'%f',1);
end
return
