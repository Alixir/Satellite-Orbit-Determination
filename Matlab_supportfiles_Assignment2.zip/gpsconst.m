%gpsconst
%
%assigns values for these commonly used constants:
%c, f1, f2, lam1, lam2, GM

% velocity of light m/sec
c =  299792458.0e+0;
% L1 and L2 frequencies
f1 = 1575.42e6;
f2 = 1227.60e6;
lam1 = c/f1;
lam2 = c/f2;

% GM in m3/sec2
gm = 3.986005e14;
%omega EPH in rad/sec
omegaE = 7292115.1467e-11;
